<!-- Copy this file into https://github.com/Letin147/Letin147/blob/main/README.md -->
<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&height=230&color=0:0B1020,50:172A39,100:1D685C&text=LETIN&fontColor=E8FFF4&fontSize=76&fontAlignY=37&desc=Multimodal%20AI%20%20%2F%20%20Agentic%20Systems&descAlignY=59&descSize=17&animation=fadeIn" width="100%" alt="Letin — Multimodal AI / Agentic Systems" />

### Building intelligence beyond prompts.

**计算机专业学生 · 多模态大模型 · 智能体系统**

[![Portfolio](https://img.shields.io/badge/PORTFOLIO-Visit%20Website-97F5C9?style=for-the-badge&labelColor=111827)](https://letin147.github.io/)
[![GitHub](https://img.shields.io/badge/GITHUB-Letin147-E8F0FF?style=for-the-badge&logo=github&logoColor=white&labelColor=111827)](https://github.com/Letin147)
[![Email](https://img.shields.io/badge/EMAIL-Let's%20Talk-89BBFF?style=for-the-badge&logo=gmail&logoColor=white&labelColor=111827)](mailto:lehhe@mails.guet.edu.cn)

</div>

---

### `01 / ABOUT ME` 👋

你好，我是 **Letin**，一名对人工智能充满好奇心的计算机专业学生。

我关注 **多模态大模型（Vision-Language Alignment）** 和 **智能体（Agentic Systems）**，希望探索 LLM 如何从感知与理解，走向规划、工具使用和复杂任务的自主执行。

> *Curious by default. Building with purpose.*

### `02 / RESEARCH INTERESTS` 🔭

| 探索方向 | 关注的问题 |
| :-- | :-- |
| 🧠 **Multimodal LLMs** | 视觉—语言对齐、跨模态表示、图文理解 |
| 🤖 **Agentic Systems** | 任务规划、工具调用、记忆与反思、自主决策 |
| 📚 **RAG** | 检索质量、重排、上下文优化、幻觉缓解 |
| ⚙️ **Efficient Fine-tuning** | LoRA / QLoRA、领域适配、模型评估 |
| 🤝 **Multi-Agent Collaboration** | 多智能体分工、协作与编排机制 |

### `03 / TECH & LEARNING STACK` 🛠️

<div align="center">

![Python](https://img.shields.io/badge/Python-121827?style=flat-square&logo=python&logoColor=3776AB)
![PyTorch](https://img.shields.io/badge/PyTorch-121827?style=flat-square&logo=pytorch&logoColor=EE4C2C)
![Transformers](https://img.shields.io/badge/Transformers-121827?style=flat-square&logo=huggingface&logoColor=FFD21E)
![LangChain](https://img.shields.io/badge/LangChain-121827?style=flat-square&logo=langchain&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-121827?style=flat-square&logo=docker&logoColor=2496ED)
![Linux](https://img.shields.io/badge/Linux-121827?style=flat-square&logo=linux&logoColor=FCC624)
![Git](https://img.shields.io/badge/Git-121827?style=flat-square&logo=git&logoColor=F05032)

</div>

**正在深入学习**：`LoRA / QLoRA` · `RAG` · `LangChain` · `AutoGen` · `CrewAI` · `Multi-Agent Orchestration`

### `04 / GITHUB ACTIVITY` 📈

<div align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Letin147&layout=compact&theme=github_dark&hide_border=true&bg_color=0D1117&title_color=97F5C9&text_color=C9D1D9" alt="Most used public repository languages" width="46%" />
  <img src="https://github-readme-streak-stats.herokuapp.com/?user=Letin147&theme=github-dark-blue&hide_border=true" alt="GitHub contribution streak" width="51%" />
</div>

> 统计组件来自第三方服务，若未正常加载，不影响主页内容。语言统计不代表技术熟练程度。

### `05 / BEYOND THE CODE` ✨

🎮 **策略游戏** — 享受推演、博弈与决策的乐趣。  
📖 **阅读与思考** — 喜欢在问题背后追问为什么。  
🚴 **城市骑行** — 用另一种速度观察世界。

### `06 / LET'S CONNECT` 💬

我很愿意交流 **多模态模型、Agent 架构、科研心得和开源协作**。

- 📮 **Email:** [lehhe@mails.guet.edu.cn](mailto:lehhe@mails.guet.edu.cn)
- 🌐 **Portfolio:** [letin147.github.io](https://letin147.github.io/)
- 🧑‍💻 **Projects:** [github.com/Letin147?tab=repositories](https://github.com/Letin147?tab=repositories)

<div align="center">

*Learn deeply. Build thoughtfully. Share openly.*

</div>
