# Letin — Personal Portfolio

个人 AI 研究者 / 开发者作品集网站。

- **入口**：`index.html`
- **样式**：`styles.css`
- **交互**：`script.js`
- **部署**：GitHub Pages（不需要构建工具、Node 或服务器）

## 发布到 GitHub Pages

1. 打开 [Letin147/Letin147.github.io](https://github.com/Letin147/Letin147.github.io)。
2. 将本压缩包内 `index.html`、`styles.css`、`script.js` 和 `assets` 文件夹上传至仓库**根目录**，不要上传外层 `letin-portfolio` 文件夹。
3. 在 GitHub 仓库 **Settings → Pages → Build and deployment** 选择 **Deploy from a branch**，Branch 选择 **main**，目录选择 **/(root)**，点击 Save。
4. 发布完成后打开 `https://letin147.github.io/`。

> 注意：网站仓库原有的 README.md 可保留，也可用这个说明覆盖。只有 README.md 不会自动成为 GitHub Pages 网站。

## 自定义

- 修改介绍文案：编辑 `index.html`。
- 修改色彩：编辑 `styles.css` 开头 `:root` 中的变量。
- 更改邮箱：搜索 `lehhe@mails.guet.edu.cn`（`index.html` 和 `script.js` 中都有）。
- 增加博客链接：目前用户尚未提供真实 CSDN URL，故未放入虚假或占位外链。
- 增加已完成项目：建议等项目可公开访问后，再添加项目卡片及真实仓库链接。

站点使用纯静态 HTML/CSS/JS；Google Fonts 如无法访问会自动回退到系统字体。

## 让 GitHub 账号主页也同步变美观

将本压缩包内 `GITHUB_PROFILE_README.md` 的全部内容，复制到另一个仓库 `Letin147/Letin147` 的 `README.md`（**不是** `Letin147.github.io` 仓库）。
